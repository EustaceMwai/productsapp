enum AuthMode{
  SignUp,
  Login
}